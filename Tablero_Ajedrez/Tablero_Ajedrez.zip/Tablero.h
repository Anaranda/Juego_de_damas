#pragma once
#include "Ficha.h"
#include <stdio.h>

using namespace std;

#define N 8 //dimensi�n del tablero

class Tablero
{
private:
	Ficha tablero[N][N];

public:
	void Inicializa();
	void DibujaTablero();

};

