#include "Tablero.h"
#include "Ficha.h"
#include <iostream>

void Tablero::Inicializa()
{
	//Se dibuja el tablero en su posici�n de comienzo de juego
	//Se considera que la esquina inferior izquierda y la superior derecha es negra y se juega sobre negras
	//Se considera piezas blancas abajo y rojas arriba

	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
		{
			tablero[i][j].SetTipo(PEON); //inicialmente todas las fichas son peones

			if ((i + j) % 2 != 0) //Si el resto de dividir (i+j) entre 2 es distinto de 0, es decir, es IMPAR: estamos sobre cuadrado negro (donde se mueven las fichas)
			{

				if (i < 3) //estamos en las 3 primeras filas ����SOLO VALIDO PARA TABLERO 8X8!!!!!
				{
					tablero[i][j].SetEstado(OCUPADO);
					tablero[i][j].SetColor(ROJO); //La pieza es roja
					tablero[i][j].DibujaFicha(i, j); //Dibujamos la ficha 
				}

				else if (i > 4) //estamos en las �ltimas 3 filas ����SOLO VALIDO PARA TABLERO 8X8!!!!!
				{
					tablero[i][j].SetEstado(OCUPADO);
					tablero[i][j].SetColor(BLANCO); //la pieza es blanca
					tablero[i][j].DibujaFicha(i, j); //Dibujamos la ficha 
				}

			}
			else
			{
				tablero[i][j].SetEstado(VACIO); // Si est� sobre cuadrados blancos pone la ficha como VACIO
			}
		}
	}
}

void Tablero::DibujaTablero()
{
	//Dibuja el tablero llamando a la funci�n DibujaFicha() al recorrer cada posici�n del tablero
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
		{
			//if (!&tablero[i][j]) //Si la direcci�n que contiene es distinto de 0 (NULL)
			//{
			//	tablero[i][j].DibujaFicha(i, j);
			//}

			if (tablero[i][j].GetEstado()) //si el estado es ocupado (1) 
			{
				tablero[i][j].DibujaFicha(i, j); //dibuja la ficha 
			}
		}
	}
}
